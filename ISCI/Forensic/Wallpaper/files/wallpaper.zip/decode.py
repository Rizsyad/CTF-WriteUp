with open("isci-wallpaper.png", "rb") as f:
    for chunk in iter(lambda: f.read(8), b''):
        print(chunk.decode('utf-8', errors="ignore"), end="")
